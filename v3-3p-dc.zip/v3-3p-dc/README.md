# IB Link Validation & Telemetry Collector

## Overview

This script connects to **IB and UFM 3.0** devices deployed in **XDR and NDR clusters**, executes `iblinkinfo` commands, and collects link-level telemetry data.

It is designed to automate large-scale fabric validation and monitoring by:

- Establishing parallel SSH connections across multiple devices
- Supporting **IB switches and UFM 3.0 devices**
- Targeting **XDR and NDR cluster deployments**
- Executing device-specific `iblinkinfo` commands
- Collecting and validating telemetry output
- Consolidating results into a timestamped report
- Categorizing and logging failures for operational visibility

The script helps in identifying connectivity issues, validating fabric health, and providing actionable insights for IB infrastructure in XDR and NDR environments.

---

## Features

- ✅ Supports UFM 3.0 and IB devices
- ✅ Parallel execution using multiprocessing
- ✅ Timestamped output files
- ✅ Structured failure reporting
- ✅ Append-based failure logging across runs
- ✅ Clean separation of RAW and FINAL outputs

---

## Directory Structure

project/
│
├── collect_ib_telemetry.py
├── config.json
├── servers.csv
├── failures.txt
└── output/
├── raw/        # Cleared at every run
└── final/      # Historical output retained

---

# Configuration Details

This section explains the fields in the `config.json` used by the IB Link Validation & Telemetry Collector.

| Field | Description |
|-------|------------|
| `process_count` | Maximum number of parallel workers |
| `credentials` | Device login credentials |
| Multiple credentials per device type | Fallback mechanism for authentication |

## Configuration (`config.json`)

```json
{
  "process_count": 25,
  "credentials": {    
    "UFM3": [
      {
        "username": "ufm3-username",
        "password": "ufm3-pwd"
      }
    ],
    "IB": [
      {
        "username": "ib-username-1",
        "password": "ib-pwd-1"
      },
      {
        "username": "ib-username-2",
        "password": "ib-pwd-2"
      }
    ]
  }
}
```


## Input File (`servers.csv`)

This CSV file provides the devices to query and their relevant metadata.

| Column Name     | Description |
|----------------|------------|
| ServerAddress   | Device IP or hostname |
| DeviceConfig    | Device type (`3.0` for UFM, `IB` for InfiniBand) |
| ClusterName     | Cluster name |
| LinkType        | Link type (e.g., XDR,NDR) |

*Ensure the CSV has headers matching the column names exactly.*

---

## Execution

Run the telemetry collector script with:

```bash
python3 collect_ib_telemetry.py servers.csv
```
## Output Format

### 📁 Output Files Overview

The script generates three types of outputs:

| Type | Location | Description |
|------|---------|------------|
| Final Output | `output/final/` | Consolidated telemetry output (timestamped) |
| Raw Output | `output/raw/` | Temporary per-device output |
| Failure Log | `failures.txt` | Append-based failure tracking |

---

## Failure Categories

The script classifies failures into standardized categories to simplify troubleshooting and reporting.

### Failure Types

| Failure Message | Description |
|----------------|------------|
| `Configuration not recognized` | Device type does not match supported values (`IB`, `3.0`) |
| `Provided credentials not working` | All configured credentials failed authentication |
| `Device Unaccessible` | Device is unreachable (network/DNS/refused connection) |
| `Device not Responding` | SSH session established but command timed out or did not respond |
| `Device Authorizable but data error` | Login successful but command output is invalid or insufficient |
| `Unknown failure` | Unexpected runtime error occurred during execution |

---

### Behavior

- ✅ Failures are logged in **append mode** in `failures.txt`
- ✅ Each execution is recorded with:
  - Automation Start Time
  - Device failure entries
  - Automation End Time and duration
- ✅ No historical data is lost across runs

---

## Author

IB Telemetry Automation Script for Link Validation & Monitoring  

Maintained by:
- Mahipal Reddy (v-mahipal@microsoft.com)
- Suvankar Bera (v-suvabera@microsoft.com)  
