import argparse
import os
import json
import shutil
import socket
import time
from multiprocessing import Pool

import pandas as pd
import paramiko
from paramiko.ssh_exception import NoValidConnectionsError, SSHException, AuthenticationException

# ============================================================
# Paths (relative)
# ============================================================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(SCRIPT_DIR, "config.json")

OUTPUT_DIR = os.path.join(SCRIPT_DIR, "output")
RAW_OUTPUT_DIR = os.path.join(OUTPUT_DIR, "raw")
FINAL_OUTPUT_DIR = os.path.join(OUTPUT_DIR, "final")

FAILURE_FILE = os.path.join(SCRIPT_DIR, "failures.txt")

# ============================================================
# Commands
# ============================================================
IB_COMMAND_SEQUENCE = ["enable", "config t", "fae iblinkinfo -l -t 50", "exit", "exit"]
UFM_3_0_COMMAND = "iblinkinfo -l -t 50"
XDR_SWITCH_COMMAND = "sudo iblinkinfo -l -t 50"

# ============================================================
# Helpers
# ============================================================
def get_output_file_name():
    timestamp = time.strftime("%Y%m%d_%H%M%S", time.gmtime())
    return os.path.join(FINAL_OUTPUT_DIR, f"IBLINKINFO_{timestamp}.txt")


def prepare_directories():
    shutil.rmtree(RAW_OUTPUT_DIR, ignore_errors=True)
    os.makedirs(RAW_OUTPUT_DIR, exist_ok=True)
    os.makedirs(FINAL_OUTPUT_DIR, exist_ok=True)


def load_config():
    if not os.path.exists(CONFIG_FILE):
        raise FileNotFoundError(f"config.json not found")

    with open(CONFIG_FILE, "r") as f:
        config = json.load(f)

    credentials = config.get("credentials")
    if not credentials:
        raise ValueError("Missing credentials in config.json")

    return config


def sanitize_filename(value):
    if not value:
        return "unknown"
    invalid = ['\\', '/', ':', '*', '?', '"', '<', '>', '|', ' ']
    for c in invalid:
        value = str(value).replace(c, "_")
    return value


def wrap_cluster_output(cluster_name, content):
    return f"#{cluster_name}\n{content}\nend\n"


def get_device_type(device_config):
    deviceType = str(device_config).lower()
    if "3.0" in deviceType:
        return "UFM3"
    elif "ib" in deviceType:
        return "IB"
    return "UNKNOWN"


# ============================================================
# SSH CLASS
# ============================================================
class SSHConnection:
    def __init__(self, host, username, password):
        self.host = host
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.username = username
        self.password = password

    def connect(self):
        self.client.connect(
            self.host,
            22,
            self.username,
            self.password,
            look_for_keys=False,
            allow_agent=False,
            timeout=60
        )

    def execute_shell_commands(self, commands):
        channel = self.client.invoke_shell()
        time.sleep(5)

        for cmd in commands:
            channel.send(cmd + "\n")
            time.sleep(2)

        output = ""
        last = time.time()

        while time.time() - last < 10:
            if channel.recv_ready():
                output += channel.recv(65535).decode(errors="ignore")
                last = time.time()
            else:
                time.sleep(1)

        return output

    def execute_single_command(self, command):
        stdin, stdout, stderr = self.client.exec_command(command, get_pty=True)
        time.sleep(5)

        output = stdout.read().decode(errors="ignore")
        error = stderr.read().decode(errors="ignore")

        if error:
            output += "\n" + error

        return output

    def close(self):
        try:
            self.client.close()
        except:
            pass


# ============================================================
# PROCESS SERVER
# ============================================================
def process_server(args):
    row, credentials = args
    server, device_config, cluster, link_type = row

    device_type = get_device_type(device_config)

    if device_type == "UNKNOWN":
        return {"status": "failure", "Device": server, "cluster": cluster, "reason": "Configuration not recognized"}

    creds = credentials.get(device_type, [])

    for cred in creds:
        ssh = SSHConnection(server, cred["username"], cred["password"])

        try:
            ssh.connect()

            if device_type == "UFM3":
                output = ssh.execute_single_command(UFM_3_0_COMMAND)

            elif device_type == "IB" and str(link_type).upper() == "XDR":
                output = ssh.execute_single_command(XDR_SWITCH_COMMAND)

            else:
                output = ssh.execute_shell_commands(IB_COMMAND_SEQUENCE)

            if output and len(output.splitlines()) > 120:
                file_path = os.path.join(
                    RAW_OUTPUT_DIR,
                    f"{sanitize_filename(cluster)}_{sanitize_filename(server)}_{int(time.time())}.txt"
                )

                with open(file_path, "w") as f:
                    f.write(wrap_cluster_output(cluster, output))

                return {"status": "success", "file": file_path}
            else:
                 return {"status": "failure", "Device": server, "cluster": cluster, "reason": " Device Authorizable but data error"}

        except AuthenticationException:
            continue
        except (NoValidConnectionsError, socket.gaierror, ConnectionRefusedError):
            return {"status": "failure", "Device": server, "cluster": cluster, "reason": "Device Unaccessible"}
        except (TimeoutError, socket.timeout, SSHException) as e:
            return {"status": "failure", "Device": server, "cluster": cluster, "reason": "Device not Responding"}
        except Exception as e:
            return {"status": "failure", "Device": server, "cluster": cluster, "reason": f"Unknown failure :{str(e)}"}
        finally:
            ssh.close()

    return {"status": "failure", "Device": server, "cluster": cluster, "reason": "Provided credentials not working"}


# ============================================================
# MERGE
# ============================================================
def combine_output_files(files):
    final_file = get_output_file_name()

    with open(final_file, "w") as out:
        for f in files:
            with open(f) as fi:
                out.write(fi.read() + "\n")

    return final_file


# ============================================================
# MAIN
# ============================================================
def main(csv):
    start_time = time.time()
    start_str = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())

    prepare_directories()
    config = load_config()
    credentials = config["credentials"]

    df = pd.read_csv(csv)
    rows = df[["ServerAdddres", "DeviceConfig", "ClusterName", "LinkType"]].values.tolist()

    #  Header append
    with open(FAILURE_FILE, "a") as f:
        f.write("\n" + "=" * 120 + "\n")
        f.write(f"Automation Start Time : {start_str}\n")
        f.write("=" * 120 + "\n")

    process_count = min(config.get("process_count", 25), len(rows))

    with Pool(process_count) as pool:
        results = pool.map(process_server, [(r, credentials) for r in rows])

    success = [r["file"] for r in results if r["status"] == "success"]
    failure = [r for r in results if r["status"] == "failure"]

    final_output_file = combine_output_files(success)

    #  Write failures (append mode)
    with open(FAILURE_FILE, "a") as f:
        for item in failure:
            f.write(f"{item['Device']:<30} {item['cluster']:<35} ------ {item['reason']}\n")

    #  Footer
    end_time = time.time()
    end_str = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())

    duration_min = int((end_time - start_time) // 60)
    duration_sec = int((end_time - start_time) % 60)

    with open(FAILURE_FILE, "a") as f:
        f.write("-" * 120 + "\n")
        f.write(f"Automation End Time: {end_str} , Duration: {duration_min} minutes and {duration_sec} seconds\n")
        f.write("-" * 120 + "\n")

    print(f"Processed: {len(rows)} | Success: {len(success)} | Failed: {len(failure)}")    


# ============================================================
# ENTRY
# ============================================================
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_filename")
    args = parser.parse_args()

    main(args.csv_filename)